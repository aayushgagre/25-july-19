package com.cg.controllers;

import java.util.LinkedList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Product;

@RestController //RestController returns MODEL And NOt View
public class HelloController {

	@GetMapping("/")//Home Page
	public String hello() {
		return "Hello World";
	}
	
	//URL = http://localhost:6969/products
	@GetMapping("/products")
	public List<Product> getProducts(){
		List<Product> list =new LinkedList<Product>();
		list.add(new Product(101,"Windows 10 pro","64Bit OS for desktop and laptops",845D));
		list.add(new Product(102,"Ubuntu","64Bit linux for desktop and laptops",456D));
		list.add(new Product(103,"Linus kaali","64Bit OS for desktop and laptops",85D));

		return list;
	}
}
